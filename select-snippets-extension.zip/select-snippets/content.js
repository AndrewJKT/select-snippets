// Select Snippets for Vincere (Select Headhunter, Oct 2026).
// In Access Evo, Vincere runs in a frame the Select Snippets bookmark and call window cannot reach. When they ask
// (read the open record, list tasks, complete a task), this loads the helper from Select Headhunter's n8n inside the
// Vincere frame, which does it with the consultant's own Vincere login and answers.
(function () {
  if (window.top === window) return; // only needed inside Access Evo's frame
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || typeof d.shq !== 'string' || d.shq === 'found' || d.shq === 'done') return;
    if (!/^https:\/\/[^/]*(access-workspace|access-evo|accessacloud)\./i.test(e.origin)) return;
    (window.__SHQ_Q = window.__SHQ_Q || []).push({ src: e.source, origin: e.origin, data: d });
    var s = document.createElement('script');
    s.src = 'https://selectheadhunter.app.n8n.cloud/webhook/qualification/frame.js?v=' + Date.now();
    (document.head || document.documentElement).appendChild(s);
  });
})();
